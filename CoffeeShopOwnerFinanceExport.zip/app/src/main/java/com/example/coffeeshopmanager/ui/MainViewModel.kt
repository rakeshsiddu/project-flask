
package com.example.coffeeshopmanager.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.coffeeshopmanager.data.CoffeeDatabase
import com.example.coffeeshopmanager.repository.CoffeeRepository
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repo: CoffeeRepository

    val orders get() = repo.orders
    val expenses get() = repo.expenses

    val todaySales get() = repo.todaySales
    val todayExpenses get() = repo.todayExpenses
    val monthSales get() = repo.monthSales
    val monthExpenses get() = repo.monthExpenses

    init {
        val dao = CoffeeDatabase.getInstance(application).coffeeDao()
        repo = CoffeeRepository(dao)
    }

    fun addOrder(summary: String, total: Double, isPaid: Boolean, paymentMethod: String, handledBy: String) {
        viewModelScope.launch {
            repo.addOrder(summary, total, isPaid, paymentMethod, handledBy)
        }
    }

    fun addExpense(category: String, description: String, amount: Double, paymentMethod: String, handledBy: String) {
        viewModelScope.launch {
            repo.addExpense(category, description, amount, paymentMethod, handledBy)
        }
    }
}

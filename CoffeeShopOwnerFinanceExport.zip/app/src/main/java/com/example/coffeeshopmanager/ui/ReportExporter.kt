
package com.example.coffeeshopmanager.ui

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.widget.Toast
import com.example.coffeeshopmanager.model.OrderEntity
import com.example.coffeeshopmanager.model.ExpenseEntity
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

data class DailyRow(
    val date: String,
    val cashSales: Double,
    val onlineSales: Double,
    val totalSales: Double,
    val cashExpenses: Double,
    val onlineExpenses: Double,
    val totalExpenses: Double,
    val profit: Double,
    val handledBy: String
)

object ReportExporter {

    private fun groupByDay(orders: List<OrderEntity>, expenses: List<ExpenseEntity>): List<DailyRow> {
        val sdfKey = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val map = linkedMapOf<String, MutableList<OrderEntity>>()
        val expMap = linkedMapOf<String, MutableList<ExpenseEntity>>()

        orders.forEach {
            val key = sdfKey.format(Date(it.timestamp))
            map.getOrPut(key) { mutableListOf() }.add(it)
        }
        expenses.forEach {
            val key = sdfKey.format(Date(it.timestamp))
            expMap.getOrPut(key) { mutableListOf() }.add(it)
        }

        val allDates = (map.keys + expMap.keys).toSortedSet()
        val rows = mutableListOf<DailyRow>()

        allDates.forEach { date ->
            val oList = map[date] ?: emptyList()
            val eList = expMap[date] ?: emptyList()

            var cashSales = 0.0
            var onlineSales = 0.0
            var cashExp = 0.0
            var onlineExp = 0.0

            val handlers = mutableSetOf<String>()

            oList.forEach { o ->
                if (o.paymentMethod.equals("Cash", true)) cashSales += o.totalAmount
                else onlineSales += o.totalAmount
                handlers.add(o.handledBy)
            }

            eList.forEach { e ->
                if (e.paymentMethod.equals("Cash", true)) cashExp += e.amount
                else onlineExp += e.amount
                handlers.add(e.handledBy)
            }

            val totalSales = cashSales + onlineSales
            val totalExp = cashExp + onlineExp
            val profit = totalSales - totalExp
            val handled = when {
                handlers.isEmpty() -> "-"
                handlers.size == 1 -> handlers.first()
                else -> "Multiple"
            }

            rows.add(
                DailyRow(
                    date = date,
                    cashSales = cashSales,
                    onlineSales = onlineSales,
                    totalSales = totalSales,
                    cashExpenses = cashExp,
                    onlineExpenses = onlineExp,
                    totalExpenses = totalExp,
                    profit = profit,
                    handledBy = handled
                )
            )
        }

        return rows
    }

    fun exportCsv(context: Context, orders: List<OrderEntity>, expenses: List<ExpenseEntity>) {
        val rows = groupByDay(orders, expenses)
        if (rows.isEmpty()) {
            Toast.makeText(context, "No data to export", Toast.LENGTH_SHORT).show()
            return
        }

        val header = "Date,Cash Sales,Online Sales,Total Sales,Cash Expenses,Online Expenses,Total Expenses,Profit,Handled By"
        val sb = StringBuilder()
        sb.appendLine(header)
        rows.forEach {
            sb.appendLine("${it.date},${it.cashSales},${it.onlineSales},${it.totalSales},${it.cashExpenses},${it.onlineExpenses},${it.totalExpenses},${it.profit},${it.handledBy}")
        }

        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, "coffee_report_${System.currentTimeMillis()}.csv")
        FileOutputStream(file).use { fos ->
            fos.write(sb.toString().toByteArray())
        }
        Toast.makeText(context, "CSV saved to Downloads: ${file.name}", Toast.LENGTH_LONG).show()
    }

    fun exportPdfA4(context: Context, orders: List<OrderEntity>, expenses: List<ExpenseEntity>) {
        exportPdfInternal(context, orders, expenses, a4 = true)
    }

    fun exportPdfMobile(context: Context, orders: List<OrderEntity>, expenses: List<ExpenseEntity>) {
        exportPdfInternal(context, orders, expenses, a4 = false)
    }

    private fun exportPdfInternal(context: Context, orders: List<OrderEntity>, expenses: List<ExpenseEntity>, a4: Boolean) {
        val rows = groupByDay(orders, expenses)
        if (rows.isEmpty()) {
            Toast.makeText(context, "No data to export", Toast.LENGTH_SHORT).show()
            return
        }

        val pdfDocument = PdfDocument()
        val paint = Paint()
        paint.textSize = 10f

        val pageWidth = if (a4) 595 else 300  // approx A4 vs mobile width in points
        val pageHeight = if (a4) 842 else 600

        var y = 40f
        var pageNumber = 1
        var page = pdfDocument.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
        var canvas = page.canvas

        fun newPageIfNeeded() {
            if (y > pageHeight - 40) {
                pdfDocument.finishPage(page)
                pageNumber++
                page = pdfDocument.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                canvas = page.canvas
                y = 40f
            }
        }

        canvas.drawText("Coffee Shop Finance Report", 20f, y, paint)
        y += 16f
        canvas.drawText("Generated: " + Date().toString(), 20f, y, paint)
        y += 20f

        // Header row
        val header = "Date | Cash S | Online S | Cash E | Online E | Profit | By"
        canvas.drawText(header, 20f, y, paint)
        y += 14f

        rows.forEach {
            newPageIfNeeded()
            val line = "${it.date} | ${"%.0f".format(it.cashSales)} | ${"%.0f".format(it.onlineSales)} | " +
                    "${"%.0f".format(it.cashExpenses)} | ${"%.0f".format(it.onlineExpenses)} | " +
                    "${"%.0f".format(it.profit)} | ${it.handledBy}"
            canvas.drawText(line, 20f, y, paint)
            y += 14f
        }

        pdfDocument.finishPage(page)

        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (!dir.exists()) dir.mkdirs()
        val suffix = if (a4) "a4" else "mobile"
        val file = File(dir, "coffee_report_${suffix}_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()

        val msg = if (a4) "A4 PDF saved to Downloads: ${file.name}" else "Mobile PDF saved to Downloads: ${file.name}"
        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
    }
}


package com.example.coffeeshopmanager

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.coffeeshopmanager.databinding.ActivityMainBinding
import com.example.coffeeshopmanager.model.OrderEntity
import com.example.coffeeshopmanager.model.ExpenseEntity
import com.example.coffeeshopmanager.ui.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val vm: MainViewModel by viewModels()

    private lateinit var orderAdapter: OrderAdapter
    private lateinit var expenseAdapter: ExpenseAdapter

    private enum class Screen { DASHBOARD, SALES, EXPENSES }
    private var currentScreen = Screen.DASHBOARD

    private var latestOrders: List<OrderEntity> = emptyList()
    private var latestExpenses: List<ExpenseEntity> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecycler()
        setupButtons()
        observeData()
        showDashboard()
    }

    private fun setupRecycler() {
        orderAdapter = OrderAdapter(emptyList())
        expenseAdapter = ExpenseAdapter(emptyList())
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
    }

    private fun setupButtons() {
        binding.btnDashboard.setOnClickListener { showDashboard() }
        binding.btnSales.setOnClickListener {
            currentScreen = Screen.SALES
            binding.tvListTitle.text = "Sales (Orders)"
            binding.recyclerView.adapter = orderAdapter
            binding.btnAdd.text = "Add Order"
            binding.btnExport.text = "Export (All)"
        }
        binding.btnExpenses.setOnClickListener {
            currentScreen = Screen.EXPENSES
            binding.tvListTitle.text = "Expenses"
            binding.recyclerView.adapter = expenseAdapter
            binding.btnAdd.text = "Add Expense"
            binding.btnExport.text = "Export (All)"
        }

        binding.btnAdd.setOnClickListener {
            when (currentScreen) {
                Screen.SALES -> showAddOrderDialog()
                Screen.EXPENSES -> showAddExpenseDialog()
                Screen.DASHBOARD -> showAddTypeChooser()
            }
        }

        binding.btnExport.setOnClickListener {
            // Export all data for now (you can later add date range filters)
            if (latestOrders.isEmpty() && latestExpenses.isEmpty()) {
                Toast.makeText(this, "No data to export", Toast.LENGTH_SHORT).show()
            } else {
                val options = arrayOf("CSV (Excel/Sheets)", "PDF - Mobile", "PDF - A4")
                AlertDialog.Builder(this)
                    .setTitle("Export Report")
                    .setItems(options) { _, which ->
                        when (which) {
                            0 -> ReportExporter.exportCsv(this, latestOrders, latestExpenses)
                            1 -> ReportExporter.exportPdfMobile(this, latestOrders, latestExpenses)
                            2 -> ReportExporter.exportPdfA4(this, latestOrders, latestExpenses)
                        }
                    }
                    .show()
            }
        }
    }

    private fun showAddTypeChooser() {
        val options = arrayOf("Add Sale (Order)", "Add Expense")
        AlertDialog.Builder(this)
            .setTitle("Choose Entry Type")
            .setItems(options) { _, which ->
                if (which == 0) showAddOrderDialog() else showAddExpenseDialog()
            }
            .show()
    }

    private fun observeData() {
        vm.orders.observe(this) {
            latestOrders = it ?: emptyList()
            orderAdapter.submitList(latestOrders)
        }
        vm.expenses.observe(this) {
            latestExpenses = it ?: emptyList()
            expenseAdapter.submitList(latestExpenses)
        }

        vm.todaySales.observe(this) { value ->
            val v = value ?: 0.0
            binding.tvTodaySales.text = "₹%.2f".format(v)
            updateTodayProfit()
        }
        vm.todayExpenses.observe(this) { value ->
            val v = value ?: 0.0
            binding.tvTodayExpenses.text = "₹%.2f".format(v)
            updateTodayProfit()
        }
        vm.monthSales.observe(this) { value ->
            val v = value ?: 0.0
            binding.tvMonthSales.text = "₹%.2f".format(v)
            updateMonthProfit()
        }
        vm.monthExpenses.observe(this) { value ->
            val v = value ?: 0.0
            binding.tvMonthExpenses.text = "₹%.2f".format(v)
            updateMonthProfit()
        }
    }

    private fun updateTodayProfit() {
        val sales = binding.tvTodaySales.text.toString().replace("₹", "").toDoubleOrNull() ?: 0.0
        val exp = binding.tvTodayExpenses.text.toString().replace("₹", "").toDoubleOrNull() ?: 0.0
        val profit = sales - exp
        binding.tvTodayProfit.text = "₹%.2f".format(profit)
    }

    private fun updateMonthProfit() {
        val sales = binding.tvMonthSales.text.toString().replace("₹", "").toDoubleOrNull() ?: 0.0
        val exp = binding.tvMonthExpenses.text.toString().replace("₹", "").toDoubleOrNull() ?: 0.0
        val profit = sales - exp
        binding.tvMonthProfit.text = "₹%.2f".format(profit)
    }

    private fun showDashboard() {
        currentScreen = Screen.DASHBOARD
        binding.recyclerView.adapter = null
        binding.tvListTitle.text = "Owner Finance Dashboard"
        binding.btnAdd.text = "Add Entry"
        binding.btnExport.text = "Export (All)"

        binding.btnAdd.setOnClickListener { showAddTypeChooser() }
    }

    private fun getHandledByFromInput(root: android.view.View): String {
        val auto = root.findViewById<AutoCompleteTextView>(R.id.etHandledBy)
        val text = auto.text.toString().trim()
        return if (text.isBlank()) "Owner" else text
    }

    private fun setupHandledByAuto(actv: AutoCompleteTextView) {
        val suggestions = arrayOf("Owner", "Chaith", "Worker", "Staff")
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, suggestions)
        actv.setAdapter(adapter)
    }

    private fun showAddOrderDialog() {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_add_order, null)
        val etSummary = view.findViewById<EditText>(R.id.etSummary)
        val etTotal = view.findViewById<EditText>(R.id.etTotal)
        val cbPaid = view.findViewById<CheckBox>(R.id.cbPaid)
        val spPayment = view.findViewById<Spinner>(R.id.spPaymentMethod)
        val etHandled = view.findViewById<AutoCompleteTextView>(R.id.etHandledBy)

        setupHandledByAuto(etHandled)

        val methods = arrayOf("Cash", "UPI", "Card", "Other")
        spPayment.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, methods)

        AlertDialog.Builder(this)
            .setTitle("Add Order (Sale)")
            .setView(view)
            .setPositiveButton("Save") { _, _ ->
                val summary = etSummary.text.toString().trim()
                val total = etTotal.text.toString().toDoubleOrNull()
                val isPaid = cbPaid.isChecked
                val method = spPayment.selectedItem.toString()
                val handledBy = getHandledByFromInput(view)

                if (summary.isBlank() || total == null) {
                    Toast.makeText(this, "Enter valid summary and total", Toast.LENGTH_SHORT).show()
                } else {
                    vm.addOrder(summary, total, isPaid, method, handledBy)
                    Toast.makeText(this, "Order saved", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAddExpenseDialog() {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_add_expense, null)
        val etCategory = view.findViewById<EditText>(R.id.etCategory)
        val etDesc = view.findViewById<EditText>(R.id.etDescription)
        val etAmount = view.findViewById<EditText>(R.id.etAmount)
        val spPayment = view.findViewById<Spinner>(R.id.spPaymentMethod)
        val etHandled = view.findViewById<AutoCompleteTextView>(R.id.etHandledBy)

        setupHandledByAuto(etHandled)

        val methods = arrayOf("Cash", "UPI", "Bank", "Other")
        spPayment.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, methods)

        AlertDialog.Builder(this)
            .setTitle("Add Expense")
            .setView(view)
            .setPositiveButton("Save") { _, _ ->
                val category = etCategory.text.toString().ifBlank { "General" }
                val desc = etDesc.text.toString()
                val amount = etAmount.text.toString().toDoubleOrNull()
                val method = spPayment.selectedItem.toString()
                val handledBy = getHandledByFromInput(view)

                if (amount == null) {
                    Toast.makeText(this, "Enter valid amount", Toast.LENGTH_SHORT).show()
                } else {
                    vm.addExpense(category, desc, amount, method, handledBy)
                    Toast.makeText(this, "Expense saved", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

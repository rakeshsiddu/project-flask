
package com.example.coffeeshopmanager.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String,
    val description: String,
    val amount: Double,
    val paymentMethod: String,
    val handledBy: String,
    val timestamp: Long
)

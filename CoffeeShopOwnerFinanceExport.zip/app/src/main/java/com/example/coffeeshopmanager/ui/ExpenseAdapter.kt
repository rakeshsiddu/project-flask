
package com.example.coffeeshopmanager.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.coffeeshopmanager.databinding.ItemRowBinding
import com.example.coffeeshopmanager.model.ExpenseEntity
import java.text.SimpleDateFormat
import java.util.*

class ExpenseAdapter(
    private var items: List<ExpenseEntity>
) : RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder>() {

    inner class ExpenseViewHolder(val binding: ItemRowBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpenseViewHolder {
        val binding = ItemRowBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ExpenseViewHolder(binding)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: ExpenseViewHolder, position: Int) {
        val exp = items[position]
        val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
        val dateStr = sdf.format(Date(exp.timestamp))

        holder.binding.tvTitle.text = "₹%.2f • %s • %s".format(exp.amount, exp.category, exp.paymentMethod)
        holder.binding.tvSubtitle.text = "${exp.description}  (By: ${exp.handledBy})"
        holder.binding.tvExtra.text = dateStr
    }

    fun submitList(newItems: List<ExpenseEntity>) {
        items = newItems
        notifyDataSetChanged()
    }
}

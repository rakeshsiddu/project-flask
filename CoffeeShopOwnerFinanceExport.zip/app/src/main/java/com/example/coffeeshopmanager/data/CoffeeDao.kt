
package com.example.coffeeshopmanager.data

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.coffeeshopmanager.model.MenuItemEntity
import com.example.coffeeshopmanager.model.OrderEntity
import com.example.coffeeshopmanager.model.ExpenseEntity

@Dao
interface CoffeeDao {

    // Menu
    @Insert
    suspend fun insertMenuItem(item: MenuItemEntity)

    @Query("SELECT * FROM menu_items ORDER BY category, name")
    fun getAllMenuItems(): LiveData<List<MenuItemEntity>>

    // Orders (sales)
    @Insert
    suspend fun insertOrder(order: OrderEntity)

    @Query("SELECT * FROM orders ORDER BY timestamp DESC")
    fun getAllOrders(): LiveData<List<OrderEntity>>

    // Expenses
    @Insert
    suspend fun insertExpense(expense: ExpenseEntity)

    @Query("SELECT * FROM expenses ORDER BY timestamp DESC")
    fun getAllExpenses(): LiveData<List<ExpenseEntity>>

    // Dashboard money calculations (today / month)
    @Query("SELECT SUM(totalAmount) FROM orders WHERE date(timestamp/1000, 'unixepoch', 'localtime') = date('now','localtime')")
    fun getTodaySales(): LiveData<Double?>

    @Query("SELECT SUM(amount) FROM expenses WHERE date(timestamp/1000, 'unixepoch', 'localtime') = date('now','localtime')")
    fun getTodayExpenses(): LiveData<Double?>

    @Query("SELECT SUM(totalAmount) FROM orders WHERE strftime('%m', timestamp/1000, 'unixepoch', 'localtime') = strftime('%m', 'now','localtime')")
    fun getThisMonthSales(): LiveData<Double?>

    @Query("SELECT SUM(amount) FROM expenses WHERE strftime('%m', timestamp/1000, 'unixepoch', 'localtime') = strftime('%m', 'now','localtime')")
    fun getThisMonthExpenses(): LiveData<Double?>
}

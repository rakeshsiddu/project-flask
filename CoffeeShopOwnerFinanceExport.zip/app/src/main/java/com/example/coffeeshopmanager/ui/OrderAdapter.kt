
package com.example.coffeeshopmanager.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.coffeeshopmanager.databinding.ItemRowBinding
import com.example.coffeeshopmanager.model.OrderEntity
import java.text.SimpleDateFormat
import java.util.*

class OrderAdapter(
    private var items: List<OrderEntity>
) : RecyclerView.Adapter<OrderAdapter.OrderViewHolder>() {

    inner class OrderViewHolder(val binding: ItemRowBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val binding = ItemRowBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return OrderViewHolder(binding)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        val order = items[position]
        val status = if (order.isPaid) "Paid" else "Pending"
        val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
        val dateStr = sdf.format(Date(order.timestamp))

        holder.binding.tvTitle.text = "₹%.2f • %s • %s".format(order.totalAmount, status, order.paymentMethod)
        holder.binding.tvSubtitle.text = "${order.itemsSummary}  (By: ${order.handledBy})"
        holder.binding.tvExtra.text = dateStr
    }

    fun submitList(newItems: List<OrderEntity>) {
        items = newItems
        notifyDataSetChanged()
    }
}

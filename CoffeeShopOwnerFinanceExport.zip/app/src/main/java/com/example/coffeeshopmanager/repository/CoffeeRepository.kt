
package com.example.coffeeshopmanager.repository

import com.example.coffeeshopmanager.data.CoffeeDao
import com.example.coffeeshopmanager.model.OrderEntity
import com.example.coffeeshopmanager.model.ExpenseEntity
import com.example.coffeeshopmanager.model.MenuItemEntity

class CoffeeRepository(private val dao: CoffeeDao) {

    val menuItems = dao.getAllMenuItems()
    val orders = dao.getAllOrders()
    val expenses = dao.getAllExpenses()

    val todaySales = dao.getTodaySales()
    val todayExpenses = dao.getTodayExpenses()
    val monthSales = dao.getThisMonthSales()
    val monthExpenses = dao.getThisMonthExpenses()

    suspend fun addMenuItem(name: String, price: Double, category: String) {
        dao.insertMenuItem(MenuItemEntity(name = name, price = price, category = category))
    }

    suspend fun addOrder(summary: String, total: Double, isPaid: Boolean, paymentMethod: String, handledBy: String) {
        dao.insertOrder(
            OrderEntity(
                itemsSummary = summary,
                totalAmount = total,
                isPaid = isPaid,
                paymentMethod = paymentMethod,
                handledBy = handledBy,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun addExpense(category: String, description: String, amount: Double, paymentMethod: String, handledBy: String) {
        dao.insertExpense(
            ExpenseEntity(
                category = category,
                description = description,
                amount = amount,
                paymentMethod = paymentMethod,
                handledBy = handledBy,
                timestamp = System.currentTimeMillis()
            )
        )
    }
}

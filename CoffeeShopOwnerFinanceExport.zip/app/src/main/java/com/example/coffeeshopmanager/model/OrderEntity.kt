
package com.example.coffeeshopmanager.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val itemsSummary: String,
    val totalAmount: Double,
    val isPaid: Boolean,
    val paymentMethod: String, // Cash, UPI, Card, etc.
    val handledBy: String,
    val timestamp: Long
)

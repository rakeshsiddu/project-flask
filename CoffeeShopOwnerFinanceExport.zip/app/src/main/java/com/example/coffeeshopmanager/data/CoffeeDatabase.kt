
package com.example.coffeeshopmanager.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.coffeeshopmanager.model.MenuItemEntity
import com.example.coffeeshopmanager.model.OrderEntity
import com.example.coffeeshopmanager.model.ExpenseEntity

@Database(
    entities = [MenuItemEntity::class, OrderEntity::class, ExpenseEntity::class],
    version = 1,
    exportSchema = false
)
abstract class CoffeeDatabase : RoomDatabase() {

    abstract fun coffeeDao(): CoffeeDao

    companion object {
        @Volatile
        private var INSTANCE: CoffeeDatabase? = null

        fun getInstance(context: Context): CoffeeDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CoffeeDatabase::class.java,
                    "coffee_owner_finance_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
